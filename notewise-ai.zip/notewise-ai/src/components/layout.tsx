import React from "react";
import { Link, useLocation } from "wouter";
import { BookText, FileText, Layers, Hash, LayoutDashboard, Plus, Sparkles, Keyboard } from "lucide-react";
import { useCreateNote, getListNotesQueryKey, getGetNoteStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createNote = useCreateNote();

  const handleCreate = () => {
    createNote.mutate(
      { data: { title: "New Note", content: "", tags: [] } },
      {
        onSuccess: (note) => {
          queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
          setLocation(`/notes/${note.id}`);
        },
      }
    );
  };

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/notes", label: "All Notes", icon: BookText },
    { href: "/flashcards", label: "Study Deck", icon: Layers },
    { href: "/tags", label: "Tags", icon: Hash },
  ];

  return (
    <div className="flex h-[100dvh] w-full bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 flex flex-col border-r border-border bg-sidebar relative overflow-hidden">
        {/* Subtle gradient decoration */}
        <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />

        {/* Brand */}
        <div className="px-5 pt-6 pb-4 relative">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-sm shadow-primary/30 group-hover:shadow-md group-hover:shadow-primary/40 transition-shadow">
              <FileText className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-serif text-xl font-semibold text-foreground tracking-tight">
              Note<span className="text-primary">Wise</span>
            </span>
          </Link>
        </div>

        {/* New Note button */}
        <div className="px-4 pb-5 relative">
          <button
            onClick={handleCreate}
            disabled={createNote.isPending}
            data-testid="button-create-note-sidebar"
            className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 active:scale-[0.98] text-primary-foreground px-4 py-2.5 rounded-lg font-medium text-sm transition-all shadow-sm shadow-primary/25 hover:shadow-md hover:shadow-primary/30 disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            New Note
          </button>
        </div>

        {/* Divider */}
        <div className="mx-4 mb-3 border-t border-border/60" />

        {/* Nav */}
        <nav className="flex-1 px-3 py-1 space-y-0.5">
          {navItems.map((item) => {
            const isActive =
              location === item.href ||
              (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                data-testid={`link-nav-${item.label.toLowerCase().replace(" ", "-")}`}
                className={`group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all relative ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
                }`}
              >
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-primary rounded-r-full" />
                )}
                <item.icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                  }`}
                />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Footer hint */}
        <div className="mx-4 mb-5 mt-3">
          <div className="rounded-lg bg-muted/60 border border-border/50 px-3 py-3">
            <div className="flex items-center gap-2 mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-primary/70" />
              <span className="text-xs font-medium text-foreground/80">Quick tip</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Open a note and hit <span className="font-medium text-foreground/70">Auto-tag</span> to let AI suggest relevant tags.
            </p>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative dot-pattern">
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-br from-primary/4 via-transparent to-transparent z-0" />
        <div className="relative z-10 flex flex-col h-full">
          {children}
        </div>
      </main>
    </div>
  );
}
