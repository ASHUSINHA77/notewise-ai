import { useGetNoteStats, useListNotes } from "@workspace/api-client-react";
import { Link } from "wouter";
import { BookText, Star, Layers, Hash, ArrowRight, Pencil } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning.";
  if (h < 17) return "Good afternoon.";
  return "Good evening.";
}

const STAT_CONFIG = [
  {
    key: "totalNotes" as const,
    label: "Notes",
    icon: BookText,
    href: "/notes",
    color: "bg-teal-50 text-teal-700 border-teal-100",
    iconBg: "bg-teal-100",
    bar: "bg-teal-400",
  },
  {
    key: "starredNotes" as const,
    label: "Starred",
    icon: Star,
    href: "/notes",
    color: "bg-amber-50 text-amber-700 border-amber-100",
    iconBg: "bg-amber-100",
    bar: "bg-amber-400",
  },
  {
    key: "totalFlashcards" as const,
    label: "Flashcards",
    icon: Layers,
    href: "/flashcards",
    color: "bg-violet-50 text-violet-700 border-violet-100",
    iconBg: "bg-violet-100",
    bar: "bg-violet-400",
  },
  {
    key: "totalTags" as const,
    label: "Tags",
    icon: Hash,
    href: "/tags",
    color: "bg-emerald-50 text-emerald-700 border-emerald-100",
    iconBg: "bg-emerald-100",
    bar: "bg-emerald-400",
  },
];

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetNoteStats();
  const { data: recentNotes, isLoading: notesLoading } = useListNotes({ limit: 5 });

  if (statsLoading || notesLoading) {
    return (
      <div className="p-10 max-w-5xl mx-auto w-full h-full">
        <div className="h-9 w-52 bg-muted rounded-lg mb-2 animate-pulse" />
        <div className="h-5 w-72 bg-muted/60 rounded mb-10 animate-pulse" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-muted rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const maxStat = Math.max(stats?.totalNotes || 0, stats?.totalFlashcards || 0, 1);

  return (
    <div className="p-8 md:p-10 max-w-5xl mx-auto w-full h-full overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
      >
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-4xl font-serif text-foreground mb-1.5 leading-tight">
            {getGreeting()}
          </h1>
          <p className="text-muted-foreground text-base">
            Your knowledge base is growing — keep writing.
          </p>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 mb-12">
          {STAT_CONFIG.map((cfg, i) => {
            const val = cfg.key === "starredNotes"
              ? stats?.starredNotes ?? 0
              : cfg.key === "totalNotes"
              ? stats?.totalNotes ?? 0
              : cfg.key === "totalFlashcards"
              ? stats?.totalFlashcards ?? 0
              : stats?.totalTags ?? 0;

            return (
              <motion.div
                key={cfg.key}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06, duration: 0.3 }}
              >
                <Link href={cfg.href}>
                  <div className={`group relative rounded-xl border p-5 cursor-pointer hover:shadow-md transition-all hover:-translate-y-0.5 ${cfg.color}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div className={`w-8 h-8 rounded-lg ${cfg.iconBg} flex items-center justify-center`}>
                        <cfg.icon className="w-4 h-4" />
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-50 transition-opacity -translate-x-1 group-hover:translate-x-0 duration-200" />
                    </div>
                    <div className="text-3xl font-serif font-semibold mb-0.5">{val}</div>
                    <div className="text-xs font-medium opacity-70">{cfg.label}</div>
                    {/* Mini progress bar */}
                    <div className="mt-3 h-0.5 bg-current/10 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${cfg.bar} rounded-full transition-all duration-700`}
                        style={{ width: `${Math.min(100, (val / maxStat) * 100)}%` }}
                      />
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>

        {/* Recent notes */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-serif text-foreground">Recent Notes</h2>
              <Link
                href="/notes"
                className="text-sm font-medium text-primary hover:underline underline-offset-4 flex items-center gap-1"
              >
                View all <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="space-y-2.5">
              {!recentNotes?.length ? (
                <div className="text-center py-14 rounded-xl border border-dashed border-border bg-card">
                  <Pencil className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No notes yet — start writing!</p>
                </div>
              ) : (
                recentNotes.map((note, index) => (
                  <motion.div
                    key={note.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.15 + index * 0.06 }}
                  >
                    <Link href={`/notes/${note.id}`} className="block">
                      <div className="group flex items-start gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/40 hover:shadow-sm transition-all cursor-pointer relative overflow-hidden">
                        {/* Left accent */}
                        <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary/0 group-hover:bg-primary/60 rounded-l-xl transition-colors" />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1">
                            {note.starred && (
                              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400 flex-shrink-0" />
                            )}
                            <span className="font-serif font-medium text-foreground truncate text-[15px]">
                              {note.title || "Untitled"}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-1 mb-2.5">
                            {note.content || "Empty note"}
                          </p>
                          <div className="flex items-center gap-2 flex-wrap">
                            {note.tags?.slice(0, 3).map((tag) => (
                              <span
                                key={tag}
                                className="px-1.5 py-0.5 bg-primary/8 text-primary/80 text-[11px] rounded font-medium"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                        </div>

                        <time className="text-[11px] text-muted-foreground whitespace-nowrap mt-0.5 flex-shrink-0">
                          {format(new Date(note.updatedAt), "MMM d")}
                        </time>
                      </div>
                    </Link>
                  </motion.div>
                ))
              )}
            </div>
          </div>

          {/* Right panel — quick actions */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-serif text-foreground mb-5">Quick Actions</h2>
            <div className="space-y-2.5">
              {[
                {
                  href: "/notes",
                  label: "Browse all notes",
                  desc: "Search, filter, organise",
                  icon: BookText,
                  accent: "text-teal-600 bg-teal-50 border-teal-100",
                  iconBg: "bg-teal-100",
                },
                {
                  href: "/flashcards",
                  label: "Study flashcards",
                  desc: "Review your knowledge",
                  icon: Layers,
                  accent: "text-violet-600 bg-violet-50 border-violet-100",
                  iconBg: "bg-violet-100",
                },
                {
                  href: "/tags",
                  label: "Explore by tag",
                  desc: "Find notes by topic",
                  icon: Hash,
                  accent: "text-emerald-600 bg-emerald-50 border-emerald-100",
                  iconBg: "bg-emerald-100",
                },
              ].map((action, i) => (
                <motion.div
                  key={action.href}
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + i * 0.08 }}
                >
                  <Link href={action.href}>
                    <div className={`group flex items-center gap-3 p-3.5 rounded-xl border cursor-pointer hover:shadow-sm transition-all hover:-translate-y-0.5 ${action.accent}`}>
                      <div className={`w-9 h-9 rounded-lg ${action.iconBg} flex items-center justify-center flex-shrink-0`}>
                        <action.icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium leading-tight">{action.label}</div>
                        <div className="text-xs opacity-60 mt-0.5">{action.desc}</div>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-50 -translate-x-1 group-hover:translate-x-0 transition-all duration-200 flex-shrink-0" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
