import { useState } from "react";
import { useListFlashcards, useDeleteFlashcard, getListFlashcardsQueryKey, getGetNoteStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Layers, ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";

export default function Flashcards() {
  const queryClient = useQueryClient();
  const { data: flashcards, isLoading } = useListFlashcards();
  const deleteFlashcard = useDeleteFlashcard();

  const [current, setCurrent] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [studyMode, setStudyMode] = useState(false);

  const handleDelete = (id: number) => {
    if (!confirm("Delete this flashcard?")) return;
    deleteFlashcard.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFlashcardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
        if (current >= (flashcards?.length ?? 1) - 1) setCurrent(Math.max(0, (flashcards?.length ?? 1) - 2));
      }
    });
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-4xl mx-auto w-full h-full">
        <div className="h-8 w-48 bg-muted rounded animate-pulse mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => <div key={i} className="h-40 bg-muted rounded-xl animate-pulse" />)}
        </div>
      </div>
    );
  }

  if (!flashcards?.length) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <div className="w-20 h-20 bg-muted rounded-2xl flex items-center justify-center mb-6">
          <Layers className="w-10 h-10 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-serif text-foreground mb-3">No flashcards yet</h2>
        <p className="text-muted-foreground max-w-sm">
          Open any note and click "Flashcards" to automatically generate study cards from your content.
        </p>
      </div>
    );
  }

  if (studyMode) {
    const card = flashcards[current];
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="w-full max-w-2xl">
          <div className="flex items-center justify-between mb-8">
            <button onClick={() => { setStudyMode(false); setFlipped(false); }} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ChevronLeft className="w-4 h-4" /> Exit Study
            </button>
            <span className="text-sm text-muted-foreground">{current + 1} / {flashcards.length}</span>
          </div>

          <div
            className="relative h-72 cursor-pointer"
            onClick={() => setFlipped(!flipped)}
            data-testid="flashcard-flip"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={flipped ? "answer" : "question"}
                initial={{ rotateY: 90, opacity: 0 }}
                animate={{ rotateY: 0, opacity: 1 }}
                exit={{ rotateY: -90, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className={`absolute inset-0 rounded-2xl border-2 p-8 flex flex-col items-center justify-center text-center ${
                  flipped
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border"
                }`}
              >
                <div className="text-xs font-medium uppercase tracking-widest mb-4 opacity-60">
                  {flipped ? "Answer" : "Question"}
                </div>
                <p className="text-xl leading-relaxed">{flipped ? card.answer : card.question}</p>
                {!flipped && <p className="text-xs mt-6 opacity-40">Click to reveal answer</p>}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={() => { setCurrent(Math.max(0, current - 1)); setFlipped(false); }}
              disabled={current === 0}
              className="p-3 rounded-full border border-border hover:bg-muted transition-colors disabled:opacity-30"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setFlipped(false)}
              className="p-3 rounded-full border border-border hover:bg-muted transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => { setCurrent(Math.min(flashcards.length - 1, current + 1)); setFlipped(false); }}
              disabled={current === flashcards.length - 1}
              className="p-3 rounded-full border border-border hover:bg-muted transition-colors disabled:opacity-30"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="flex gap-1 justify-center mt-6">
            {flashcards.map((_, i) => (
              <button
                key={i}
                onClick={() => { setCurrent(i); setFlipped(false); }}
                className={`h-1.5 rounded-full transition-all ${i === current ? "w-6 bg-primary" : "w-1.5 bg-border"}`}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 md:p-10 max-w-5xl mx-auto w-full h-full overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-serif text-foreground">Study Deck</h1>
          <p className="text-muted-foreground mt-1">{flashcards.length} flashcard{flashcards.length !== 1 ? "s" : ""} ready</p>
        </div>
        <button
          onClick={() => { setCurrent(0); setFlipped(false); setStudyMode(true); }}
          data-testid="button-start-study"
          className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md font-medium transition-colors"
        >
          <Layers className="w-4 h-4" />
          Start Studying
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence>
          {flashcards.map((card, index) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2, delay: index * 0.04 }}
              data-testid={`card-flashcard-${card.id}`}
              className="group bg-card border border-border rounded-xl p-5 hover:border-primary/30 hover:shadow-sm transition-all"
            >
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2">Question</div>
              <p className="text-foreground text-sm font-medium mb-4 line-clamp-2">{card.question}</p>
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2">Answer</div>
              <p className="text-muted-foreground text-sm line-clamp-2">{card.answer}</p>
              <div className="flex items-center justify-end mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => handleDelete(card.id)}
                  data-testid={`button-delete-flashcard-${card.id}`}
                  className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
