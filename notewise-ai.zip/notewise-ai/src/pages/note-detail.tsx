import { useState, useEffect, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import {
  useGetNote, useUpdateNote, useAutoTagNote, useGenerateFlashcards, useStarNote, useDeleteNote,
  getGetNoteQueryKey, getListNotesQueryKey, getGetNoteStatsQueryKey, getListFlashcardsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Wand2, Layers, Star, Trash2, ChevronLeft, Loader2, Save } from "lucide-react";
import { format } from "date-fns";

export default function NoteDetail() {
  const [, params] = useRoute("/notes/:id");
  const [, setLocation] = useLocation();
  const id = params ? parseInt(params.id, 10) : 0;
  const queryClient = useQueryClient();

  const { data: note, isLoading } = useGetNote(id, { query: { enabled: !!id, queryKey: getGetNoteQueryKey(id) } });

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updateNote = useUpdateNote();
  const autoTag = useAutoTagNote();
  const generateFlashcards = useGenerateFlashcards();
  const starNote = useStarNote();
  const deleteNote = useDeleteNote();

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setTags(note.tags);
      setIsDirty(false);
    }
  }, [note]);

  const save = () => {
    if (!isDirty) return;
    updateNote.mutate({ id, data: { title, content, tags } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetNoteQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
        setIsDirty(false);
      }
    });
  };

  const scheduleAutoSave = () => {
    setIsDirty(true);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(save, 1500);
  };

  const handleAutoTag = () => {
    autoTag.mutate({ id }, {
      onSuccess: (updated) => {
        setTags(updated.tags);
        queryClient.invalidateQueries({ queryKey: getGetNoteQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
      }
    });
  };

  const handleGenerateFlashcards = () => {
    generateFlashcards.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFlashcardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteQueryKey(id) });
      }
    });
  };

  const handleStar = () => {
    starNote.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetNoteQueryKey(id) })
    });
  };

  const handleDelete = () => {
    if (!confirm("Delete this note and all its flashcards?")) return;
    deleteNote.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
        setLocation("/notes");
      }
    });
  };

  const addTag = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && tagInput.trim()) {
      const newTag = tagInput.trim().toLowerCase();
      if (!tags.includes(newTag)) {
        const newTags = [...tags, newTag];
        setTags(newTags);
        setIsDirty(true);
        updateNote.mutate({ id, data: { tags: newTags } }, {
          onSuccess: () => queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() })
        });
      }
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    const newTags = tags.filter(t => t !== tag);
    setTags(newTags);
    updateNote.mutate({ id, data: { tags: newTags } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() })
    });
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-4xl mx-auto w-full h-full">
        <div className="h-8 w-48 bg-muted rounded animate-pulse mb-6" />
        <div className="h-12 w-3/4 bg-muted rounded animate-pulse mb-4" />
        <div className="space-y-3">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-5 bg-muted rounded animate-pulse" style={{ width: `${70 + i * 7}%` }} />)}
        </div>
      </div>
    );
  }

  if (!note) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <p className="text-muted-foreground">Note not found.</p>
        <button onClick={() => setLocation("/notes")} className="mt-4 text-primary hover:underline">Back to notes</button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col h-full overflow-hidden"
    >
      <div className="flex items-center justify-between px-8 py-4 border-b border-border bg-card/50">
        <button
          onClick={() => setLocation("/notes")}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          data-testid="button-back-notes"
        >
          <ChevronLeft className="w-4 h-4" /> All Notes
        </button>

        <div className="flex items-center gap-2">
          {isDirty && (
            <button
              onClick={save}
              disabled={updateNote.isPending}
              data-testid="button-save-note"
              className="flex items-center gap-1.5 text-sm px-3 py-1.5 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            >
              {updateNote.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              Save
            </button>
          )}
          <button
            onClick={handleAutoTag}
            disabled={autoTag.isPending}
            data-testid="button-auto-tag"
            className="flex items-center gap-1.5 text-sm px-3 py-1.5 border border-border rounded-md hover:bg-muted transition-colors text-foreground"
          >
            {autoTag.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
            Auto-tag
          </button>
          <button
            onClick={handleGenerateFlashcards}
            disabled={generateFlashcards.isPending}
            data-testid="button-generate-flashcards"
            className="flex items-center gap-1.5 text-sm px-3 py-1.5 border border-border rounded-md hover:bg-muted transition-colors text-foreground"
          >
            {generateFlashcards.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Layers className="w-3.5 h-3.5" />}
            Flashcards
          </button>
          <button
            onClick={handleStar}
            data-testid="button-star-note"
            className="p-2 rounded-md hover:bg-muted transition-colors"
          >
            <Star className={`w-4 h-4 ${note.starred ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`} />
          </button>
          <button
            onClick={handleDelete}
            data-testid="button-delete-note"
            className="p-2 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-8 py-8 max-w-4xl mx-auto w-full">
        <input
          value={title}
          onChange={e => { setTitle(e.target.value); scheduleAutoSave(); }}
          placeholder="Note title..."
          data-testid="input-note-title"
          className="w-full text-4xl font-serif font-medium text-foreground bg-transparent border-none outline-none placeholder:text-muted-foreground/50 mb-3"
        />

        <div className="text-xs text-muted-foreground mb-6">
          {format(new Date(note.updatedAt), "MMMM d, yyyy 'at' h:mm a")} · {note.flashcardCount} flashcard{note.flashcardCount !== 1 ? "s" : ""}
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {tags.map(tag => (
            <span key={tag} className="flex items-center gap-1 px-2 py-0.5 bg-primary/10 text-primary text-sm rounded-md font-medium">
              {tag}
              <button onClick={() => removeTag(tag)} className="text-primary/60 hover:text-primary ml-0.5 leading-none">×</button>
            </span>
          ))}
          <input
            value={tagInput}
            onChange={e => setTagInput(e.target.value)}
            onKeyDown={addTag}
            placeholder="Add tag..."
            data-testid="input-tag"
            className="px-2 py-0.5 bg-transparent border-none outline-none text-sm text-muted-foreground placeholder:text-muted-foreground/40 w-24 min-w-0"
          />
        </div>

        <textarea
          value={content}
          onChange={e => { setContent(e.target.value); scheduleAutoSave(); }}
          placeholder="Start writing your note..."
          data-testid="textarea-note-content"
          className="w-full min-h-96 text-foreground/90 bg-transparent border-none outline-none resize-none text-base leading-relaxed placeholder:text-muted-foreground/40 font-sans"
          rows={20}
        />
      </div>
    </motion.div>
  );
}
