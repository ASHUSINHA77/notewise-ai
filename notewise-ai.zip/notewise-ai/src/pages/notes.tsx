import { useState } from "react";
import { useListNotes, useCreateNote, useDeleteNote, useStarNote, getListNotesQueryKey, getGetNoteStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Search, Star, Trash2, BookText, Tag } from "lucide-react";
import { format } from "date-fns";

export default function Notes() {
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("");
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: notes, isLoading } = useListNotes({ search: search || undefined, tag: tagFilter || undefined });
  const createNote = useCreateNote();
  const deleteNote = useDeleteNote();
  const starNote = useStarNote();

  const handleCreate = () => {
    createNote.mutate({ data: { title: "Untitled Note", content: "", tags: [] } }, {
      onSuccess: (note) => {
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
        setLocation(`/notes/${note.id}`);
      }
    });
  };

  const handleDelete = (id: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm("Delete this note?")) return;
    deleteNote.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNoteStatsQueryKey() });
      }
    });
  };

  const handleStar = (id: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    starNote.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
      }
    });
  };

  return (
    <div className="p-8 md:p-10 max-w-5xl mx-auto w-full h-full overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-serif text-foreground">All Notes</h1>
          <p className="text-muted-foreground mt-1">{notes?.length ?? 0} notes in your collection</p>
        </div>
        <button
          onClick={handleCreate}
          disabled={createNote.isPending}
          data-testid="button-create-note"
          className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md font-medium transition-colors disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          New Note
        </button>
      </div>

      <div className="flex gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search notes..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            data-testid="input-search-notes"
            className="w-full pl-9 pr-4 py-2 bg-card border border-border rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        {tagFilter && (
          <button
            onClick={() => setTagFilter("")}
            className="flex items-center gap-1 px-3 py-2 bg-primary/10 text-primary rounded-md text-sm font-medium hover:bg-primary/20 transition-colors"
          >
            <Tag className="w-3 h-3" />
            {tagFilter} ×
          </button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />
          ))}
        </div>
      ) : notes?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mb-4">
            <BookText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">No notes found</h3>
          <p className="text-muted-foreground mb-6 max-w-sm">
            {search || tagFilter ? "Try adjusting your search or filter." : "Start capturing your thoughts by creating your first note."}
          </p>
          {!search && !tagFilter && (
            <button onClick={handleCreate} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium hover:bg-primary/90 transition-colors">
              <Plus className="w-4 h-4" /> Create your first note
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          <AnimatePresence>
            {notes?.map((note, index) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2, delay: index * 0.03 }}
              >
                <Link href={`/notes/${note.id}`}>
                  <div
                    data-testid={`card-note-${note.id}`}
                    className="group flex items-start gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-foreground truncate">{note.title}</h3>
                        {note.starred && <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500 flex-shrink-0" />}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1 mb-2">{note.content || "No content"}</p>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">{format(new Date(note.updatedAt), "MMM d, yyyy")}</span>
                        {note.tags.length > 0 && (
                          <div className="flex gap-1 flex-wrap">
                            {note.tags.slice(0, 3).map(tag => (
                              <button
                                key={tag}
                                onClick={(e) => { e.preventDefault(); e.stopPropagation(); setTagFilter(tag); }}
                                className="px-1.5 py-0.5 bg-primary/10 text-primary text-xs rounded font-medium hover:bg-primary/20 transition-colors"
                              >
                                {tag}
                              </button>
                            ))}
                            {note.tags.length > 3 && <span className="text-xs text-muted-foreground">+{note.tags.length - 3}</span>}
                          </div>
                        )}
                        {note.flashcardCount > 0 && (
                          <span className="text-xs text-muted-foreground">{note.flashcardCount} cards</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                      <button
                        onClick={e => handleStar(note.id, e)}
                        data-testid={`button-star-${note.id}`}
                        className="p-1.5 rounded hover:bg-muted transition-colors"
                      >
                        <Star className={`w-4 h-4 ${note.starred ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`} />
                      </button>
                      <button
                        onClick={e => handleDelete(note.id, e)}
                        data-testid={`button-delete-${note.id}`}
                        className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
