import { useListTags, useListNotes } from "@workspace/api-client-react";
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Hash, ChevronRight } from "lucide-react";

export default function Tags() {
  const { data: tags, isLoading } = useListTags();
  const [selected, setSelected] = useState<string | null>(null);
  const { data: tagNotes, isLoading: notesLoading } = useListNotes(
    selected ? { tag: selected } : {},
  );

  if (isLoading) {
    return (
      <div className="p-8 max-w-4xl mx-auto w-full h-full">
        <div className="h-8 w-32 bg-muted rounded animate-pulse mb-6" />
        <div className="flex flex-wrap gap-3">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-8 bg-muted rounded-full animate-pulse" style={{ width: `${60 + i * 15}px` }} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 md:p-10 max-w-5xl mx-auto w-full h-full overflow-y-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-serif text-foreground">Tags</h1>
        <p className="text-muted-foreground mt-1">{tags?.length ?? 0} unique tags across your notes</p>
      </div>

      {!tags?.length ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mb-4">
            <Hash className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">No tags yet</h3>
          <p className="text-muted-foreground max-w-sm">Tags appear here once you add them to notes or use the Auto-tag feature.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-4">Browse by tag</h2>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, index) => (
                <motion.button
                  key={tag.name}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.04 }}
                  onClick={() => setSelected(selected === tag.name ? null : tag.name)}
                  data-testid={`button-tag-${tag.name}`}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                    selected === tag.name
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-primary/10 text-primary hover:bg-primary/20"
                  }`}
                >
                  <Hash className="w-3 h-3" />
                  {tag.name}
                  <span className={`text-xs px-1 py-0.5 rounded-full ${selected === tag.name ? "bg-white/20" : "bg-primary/10"}`}>
                    {tag.count}
                  </span>
                </motion.button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2">
            {selected ? (
              <div>
                <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-4">
                  Notes tagged "{selected}"
                </h2>
                {notesLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {tagNotes?.map(note => (
                      <Link key={note.id} href={`/notes/${note.id}`}>
                        <div
                          data-testid={`card-tagged-note-${note.id}`}
                          className="flex items-center justify-between p-4 bg-card border border-border rounded-xl hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer"
                        >
                          <div>
                            <p className="font-medium text-foreground">{note.title}</p>
                            <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">{note.content || "No content"}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center text-muted-foreground">
                <Hash className="w-10 h-10 mb-3 opacity-30" />
                <p>Select a tag to see its notes</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
